SELECT 
    channel_used, 
    SUM(conversion_rate) AS totalconversions,
    RANK() OVER (ORDER BY SUM(conversion_rate) DESC) AS rank
FROM campaigndata
GROUP BY channel_used
ORDER BY totalconversions DESC;
