SELECT 
    Campaign_ID, 
    Company, 
    ROI
FROM campaigndata
ORDER BY ROI DESC
LIMIT 1;
