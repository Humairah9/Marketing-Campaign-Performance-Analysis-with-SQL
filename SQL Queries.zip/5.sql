SELECT 
    (SUM(Clicks) * 100.0 / SUM(Impressions)) AS OverallCTR
FROM campaigndata;
