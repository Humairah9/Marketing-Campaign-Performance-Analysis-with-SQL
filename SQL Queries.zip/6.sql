Select 
	campaign_id,Company,
    cast (Acquisition_cost As NUMERIC)/conversion_Rate AS costperconversion
	FROM campaigndata
	Order by costperconversion ASC
LIMIT 1;